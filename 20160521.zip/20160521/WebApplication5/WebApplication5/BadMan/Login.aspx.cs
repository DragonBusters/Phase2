﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5.BadMan
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AdminLogin_Click(object sender, EventArgs e)
        {
            if (adminName.Text.Equals("Admin") && adminPass.Text.Equals("Admin"))
            {
                Response.Redirect("AdminMenu.aspx");
            }
        }
    }
}