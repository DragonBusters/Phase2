﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5.BadMan
{
    public partial class ActivateCardReadWrite : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        [System.Web.Services.WebMethod]
        public static string loadCardRWID()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select CardRWId from [CardRW] where SetActivationStatus='Inactive'", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[CardRW]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[CardRW]"].Rows)
            {
                serviceProviders.Add(row["CardRWId"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }

        [System.Web.Services.WebMethod]
        public static string loadStaffId()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select StaffId from [SPStaff]", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[SPStaff]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[SPStaff]"].Rows)
            {
                serviceProviders.Add(row["StaffId"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }

        [System.Web.Services.WebMethod]
        public static String fillLabel(String staffId)
        {
            String firstName = "";
            String lastName = "";
            String Address = "";
            String SPName = "";
            List<String> jsonString = new List<string>();
            try
            {
                string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";


                using (SqlConnection connection = new SqlConnection(constring))
                {
                    string query = "SELECT Fname,Lname,Address, SPName FROM [SPStaff] where StaffId='" + staffId + "'";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        reader.Read();
                        firstName=reader.GetString(0);
                        lastName = reader.GetString(1);
                        Address = reader.GetString(2);
                        SPName = reader.GetString(3);
                        reader.Close();
                    }
                    connection.Close();
                }
            }
            catch (Exception)
            {

            }
            jsonString.Add(firstName);
            jsonString.Add(lastName);
            jsonString.Add(Address);
            jsonString.Add(SPName);
            return JsonConvert.SerializeObject(jsonString);
        }


        [System.Web.Services.WebMethod]
        public static String MapItems(String cardRWId, String staffId, String Fname, String SPName)
        {
            SqlConnection conn1 = null;
            try
            {

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [ActiveCdRW] values(@CardRWId,@ServiceProviderAllocated,@AllocatedPerson,@ActivatedDate)";
                comm.Parameters.AddWithValue("@CardRWId", cardRWId);
                comm.Parameters.AddWithValue("@ServiceProviderAllocated", SPName);
                comm.Parameters.AddWithValue("@AllocatedPerson", Fname);
                comm.Parameters.AddWithValue("@ActivatedDate", DateTime.Now.ToString("yyyy-MM-dd"));
                
                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                conn.Close();
                conn1 = new SqlConnection();
                conn1.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm1 = new SqlCommand();
                comm1.CommandText = "update [CardRW] set SetActivationStatus='Active' where CardRWId=@cardNumber";
                comm1.Parameters.AddWithValue("@cardNumber", cardRWId);

                conn1.Open();
                comm1.Connection = conn1;
                int ret1 = Convert.ToInt32(comm1.ExecuteNonQuery());

                if (ret1 == 1)
                {
                    return "Mapped Sucessfully";
                }

                else
                {

                    return "Mapping Failed";
                }
            }
            catch (Exception)
            {

            }
            finally
            {

                conn1.Close();
            }
            return "Mapping Failed";
        }

    }
}