﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;

namespace WebApplication5.BadMan
{
    public partial class ServiceProvider : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btRegisterServiceProvider_Click(object sender, EventArgs e)
        {
            SqlConnection conn = null;
            try
            {
               conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [ServiceProvider] values(@SPId,@ServiceName,@EstdYear,@Address)";
                comm.Parameters.AddWithValue("@SPId", tbSPID.Text);
                comm.Parameters.AddWithValue("@ServiceName", tbName.Text);
                comm.Parameters.AddWithValue("@EstdYear", tbEstd.Text);
                comm.Parameters.AddWithValue("@Address", tbAddress1.Text);

                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                if (ret == 1)
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Service Provider Registration Successfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Registration Successfull'); window.location='AdminMenu.aspx';", true);

                }
                else
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Service Provider Registration Unsuccessfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                    return;
                }
                conn.Close();

            }
            catch (Exception)
            {
                successLabel.Visible = true;
                successLabel.Text = "Service Provider Registration Unsuccessfull";
                conn.Close();
                System.Threading.Thread.Sleep(1000);
                Response.Redirect(Request.RawUrl);
                //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                return;
            }
        }
    }
}