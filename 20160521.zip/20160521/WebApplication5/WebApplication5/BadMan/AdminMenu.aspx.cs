﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5.BadMan
{
    public partial class AdminMenu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Transactions_Click(object sender, EventArgs e)
        {
            Response.Redirect("Transactions.aspx");
        }
        protected void btn_ActivateCardRW_Click(object sender, EventArgs e)
        {
            Response.Redirect("ActivateCardReadWrite.aspx");
        }
        protected void btn_ActivateUserCard_Click(object sender, EventArgs e)
        {

            Response.Redirect("ActivateUserCard.aspx");
        }

        protected void btn_AddServiceProvider_Click(object sender, EventArgs e)
        {
            Response.Redirect("ServiceProvider.aspx");

        }

        protected void btn_CardRWRegistration_Click(object sender, EventArgs e)
        {
            Response.Redirect("CardRWRegistration.aspx");
        }

        protected void btn_CardRegistration_Click(object sender, EventArgs e)
        {
            Response.Redirect("CardRegistration.aspx");
        }

        protected void btn_AdminRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminRegister.aspx");
        }

    }
}