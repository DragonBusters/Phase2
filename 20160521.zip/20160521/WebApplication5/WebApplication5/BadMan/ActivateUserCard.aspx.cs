﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Newtonsoft.Json;

namespace WebApplication5.BadMan
{
    public partial class ActivateUserCard : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        [System.Web.Services.WebMethod]
        public static string loadCardNumbers()
        {
            List<String> serviceProviders = new List<string>();
            try
            {
                string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
                


                SqlDataAdapter da = new SqlDataAdapter("select cardNumber from [PayCard] where CardActivationStatus='Inactive' and discardedcard='No'", constring);
                DataSet ds = new DataSet();
                da.Fill(ds, "[PayCard]");

                //List<string> authorNames = new List<string>();
                foreach (DataRow row in ds.Tables["[PayCard]"].Rows)
                {
                    serviceProviders.Add(row["cardNumber"].ToString());

                }
            }
            catch (Exception)
            {

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }



        [System.Web.Services.WebMethod]
        public static String MapItems(String cardNumber, String userId)
        {
            SqlConnection conn1 = null;
            try
            {
              
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [UserPayCard] values(@UserId,@CardNumber,@LastTranDate1,@LastTranValue1,@LastTranDate2,@LastTranValue2,@CurrentBalance)";
                comm.Parameters.AddWithValue("@UserId", userId);
                comm.Parameters.AddWithValue("@CardNumber", cardNumber);
                comm.Parameters.AddWithValue("@LastTranDate1", DateTime.Now.ToString("yyyy-MM-dd"));
                comm.Parameters.AddWithValue("@LastTranValue1", 0);
                comm.Parameters.AddWithValue("@LastTranDate2", DateTime.Now.ToString("yyyy-MM-dd"));
                comm.Parameters.AddWithValue("@LastTranValue2", 0);
                comm.Parameters.AddWithValue("@CurrentBalance", 0);

                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                conn.Close();
                 conn1 = new SqlConnection();
                conn1.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm1 = new SqlCommand();
                comm1.CommandText = "update [PayCard] set CardActivationStatus='Active' where CardNumber=@cardNumber";
                comm1.Parameters.AddWithValue("@cardNumber", cardNumber);

                conn1.Open();
                comm1.Connection = conn1;
                int ret1 = Convert.ToInt32(comm1.ExecuteNonQuery());
               
                if (ret1 == 1)
                {
                    return "Mapped Sucessfully";
                }

                else
                {

                    return "Mapping Failed";
                }
            }
            catch (Exception)
            {

            }
            finally
            {
                
                conn1.Close();
            }
            return "Mapping Failed";
        }




        [System.Web.Services.WebMethod]
        public static string loadUserId()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select EmailId from [User]", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[User]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[User]"].Rows)
            {
                serviceProviders.Add(row["EmailId"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }


        
            }


        }
       
    