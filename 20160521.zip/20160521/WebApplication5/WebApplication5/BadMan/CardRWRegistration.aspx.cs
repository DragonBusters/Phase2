﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;

namespace WebApplication5.BadMan
{
    public partial class CardRWRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btRegisterRWCard_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [CardRW] values(@CardRWId,@VendorName,@SerialNumber,@MACId,@SetActivationStatus)";
                comm.Parameters.AddWithValue("@CardRWId", tbCardRWID.Text);
                comm.Parameters.AddWithValue("@VendorName", tbVendorName.Text);
                comm.Parameters.AddWithValue("@SerialNumber", tbSerialNumber.Text);
                comm.Parameters.AddWithValue("@MACId", tbMacID.Text);
                comm.Parameters.AddWithValue("@SetActivationStatus","Inactive");
            
                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                if (ret == 1)
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Card Reader Registration successfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Registration Successfull'); window.location='AdminMenu.aspx';", true);

                }
                else
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Card Reader Registration Unsuccessfull";
                    //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    return;
                }
                conn.Close();

            }
            catch (Exception)
            {
                successLabel.Visible = true;
                successLabel.Text = "Card Reader Registration Unsuccessfull";
                System.Threading.Thread.Sleep(1000);
                Response.Redirect(Request.RawUrl);
               //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                return;
            }
            
        }
    }
}