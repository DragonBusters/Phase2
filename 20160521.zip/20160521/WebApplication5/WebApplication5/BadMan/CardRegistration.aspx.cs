﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;


namespace WebApplication5.BadMan
{
    public partial class CardRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btRegisterCard_Click(object sender, EventArgs e)
        {
            try{
             SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [PayCard] values(@CardNumber,@CardVendor,@SerialNumber,@CardActivationStatus,@discardedcard)";
                comm.Parameters.AddWithValue("@CardNumber", tbCardNumber.Text);
                comm.Parameters.AddWithValue("@CardVendor", tbCardVendor.Text);
                comm.Parameters.AddWithValue("@SerialNumber", tbSerialNumber.Text);
                comm.Parameters.AddWithValue("@CardActivationStatus", "Inactive");
                comm.Parameters.AddWithValue("@discardedcard", "No");
                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                if (ret == 1)
                {
                    successLabel.Visible = true;
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Card Registration Successfull'); window.location='AdminMenu.aspx';", true);
                    successLabel.Text = "Card Registration successfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                }
                else
                {
                    //Response.Write("<script language=javascript>alert('Card Registration Failed')</script>");
                    successLabel.Visible = true;
                    successLabel.Text = "Card Registration Unsuccessfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    return;
                }
                conn.Close();

            }
            catch (Exception)
            {
                //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                successLabel.Visible = true;
                successLabel.Text = "Card Registration Unsuccessfull";
                System.Threading.Thread.Sleep(1000);
                Response.Redirect(Request.RawUrl);
                return;
            }
        }
    }
}