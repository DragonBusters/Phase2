﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;


namespace WebApplication5
{

    public partial class SignUp : System.Web.UI.Page
    {

        public string sha256(string password)//passed
        {
          
            System.Security.Cryptography.SHA256Managed crypt = new System.Security.Cryptography.SHA256Managed();
            System.Text.StringBuilder hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(password), 0, Encoding.UTF8.GetByteCount(password));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }



        protected void Page_Load(object sender, EventArgs e)
        {
            successLabel.Visible = false;
            tbRegisDate.Text = DateTime.Now.ToString("yyyy-MM-dd");

        }


        protected void btSignup_Click(object sender, EventArgs e)
        {
            SqlConnection conn = null;
            try
            {
                if (!tbpass.Text.Equals(tbconfirmPass.Text))
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Password and Confirm Password do not match";
                    return;
                }
                Boolean match = false;
                string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
                SqlDataAdapter da = new SqlDataAdapter("select EmailId from [User]", constring);
                DataSet ds = new DataSet();
                da.Fill(ds, "[User]");

                //List<string> authorNames = new List<string>();
                foreach (DataRow row in ds.Tables["[User]"].Rows)
                {
                    //authorNames.Add(row["EmailId"].ToString());
                    if (string.Equals(tbUserid.Text, row["EmailId"].ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        match = true;
                    }
                }
                if (match == true)
                {
                    successLabel.Visible = true;
                    successLabel.Text = "This Email ID has already been taken please Try a different one";
                    return;
                }
                

                //---------------------------------------------------------------------------------------------
                string query = "SELECT MAX(UserId) FROM [User]";
                
                SqlConnection conn1 = new SqlConnection(constring);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;

                int id = 0;
                
                try
                {
                    conn1.Open();
                    cmd.Connection = conn1;
                    
                    
                    id= Convert.ToInt32(cmd.ExecuteScalar());
                    id++;

                    
                   
                    
                    
                    
                }
                catch (Exception ex)
                {
                    id = 1;
                }
                finally
                {
                    conn1.Close();
                }


                //--------------------------------------------------------------------------------------------------------
                conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "insert into [User] values(@UserId,@EmailId,@Fname,@Password,@Lname,@Address,@CellNumber,@RegDate,@Age)";
                comm.Parameters.AddWithValue("@UserId", id);
                comm.Parameters.AddWithValue("@EmailId", tbUserid.Text);
                comm.Parameters.AddWithValue("@Fname", tbFname.Text);
                comm.Parameters.AddWithValue("@Password", tbpass.Text);
                comm.Parameters.AddWithValue("@Lname", tbLname.Text);
                comm.Parameters.AddWithValue("@Address", tbAddress.Text);
                comm.Parameters.AddWithValue("@CellNumber", tbCellNumber.Text);
                comm.Parameters.AddWithValue("@RegDate", tbRegisDate.Text);
                comm.Parameters.AddWithValue("@Age", tbAge.Text);
                conn.Open();
                comm.Connection = conn;
                int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                if (ret == 1)
                {
                    String hashPass=sha256(tbpass.Text);
                    SqlConnection conn2 = new SqlConnection();
                    conn2.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                    SqlCommand comm1 = new SqlCommand();
                    comm1.CommandText = "insert into [AuthN] values(@Uid,@HashPwd)";
                    comm1.Parameters.AddWithValue("@Uid",tbUserid.Text);
                    comm1.Parameters.AddWithValue("@HashPwd",hashPass);
                    conn2.Open();
                    comm1.Connection = conn2;
                    int ret1 = Convert.ToInt32(comm1.ExecuteNonQuery());
                    conn2.Close();
                   //ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "alert('Registration Successfull'); window.location='SignIn.aspx';", true);
                    successLabel.Visible = true;
                    successLabel.Text = "Registration Successfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                }
                else
                {
                    successLabel.Visible = true;
                    successLabel.Text = "Registration Unsuccessfull";
                    System.Threading.Thread.Sleep(1000);
                    Response.Redirect(Request.RawUrl);
                    //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                    return;
                }
                conn.Close();
                
            }
            catch (Exception)
            {
                conn.Close();
                successLabel.Visible = true;
                successLabel.Text = "Registration Unsuccessfull";
                System.Threading.Thread.Sleep(1000);
                Response.Redirect(Request.RawUrl);
                //Response.Write("<script language=javascript>alert('invalid registration')</script>");
                return;
            }
        }
    }
}

//"INSERT INTO user (UserId, FName, LName, Address, CellNumber, RegDate, Age) VALUES (?,?,?,?,?,?,?)"