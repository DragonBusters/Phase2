﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;

namespace WebApplication5
{
    public partial class SignIn : System.Web.UI.Page
    {

        public string sha256(string password)//passed
        {
            
            
            System.Security.Cryptography.SHA256Managed crypt = new System.Security.Cryptography.SHA256Managed();
            System.Text.StringBuilder hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(password), 0, Encoding.UTF8.GetByteCount(password));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            SqlConnection conn=null;

            try
            {
               
                 conn = new SqlConnection();
                conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                SqlCommand cmd = new SqlCommand("select count(*) from [AuthN] where Uid = @username and HashPwd = @password",conn);

                SqlParameter user = new SqlParameter();
                user.ParameterName = "@username";
                user.Value = UserId.Text;
                cmd.Parameters.Add(user);

                String hashedPassword = sha256(Password.Text);
                SqlParameter pass = new SqlParameter();
                pass.ParameterName = "@password";
                pass.Value = hashedPassword;
                cmd.Parameters.Add(pass);

                conn.Open();

                int count = (int)cmd.ExecuteScalar();
                if (count > 0)
                {
                    Response.Write("<script>alert('Login successfull')</script>");
                }
                else
                {
                    errorMsg.Visible = true;
                    
                }
            }
            catch (Exception)
            {

            }
            finally
            {
                if (conn != null) conn.Close();
            }
        }
        
    }
}