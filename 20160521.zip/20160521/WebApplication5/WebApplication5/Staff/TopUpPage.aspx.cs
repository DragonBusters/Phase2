﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5.Staff
{
    public partial class TopUpPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string loadCardRWID()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select CardRWId from [CardRW] where SetActivationStatus='Active'", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[CardRW]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[CardRW]"].Rows)
            {
                serviceProviders.Add(row["CardRWId"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }


        [System.Web.Services.WebMethod]
        public static string loadCardNumbers()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select cardNumber from [PayCard] where CardActivationStatus='Active' and DiscardedCard='No'", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[PayCard]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[PayCard]"].Rows)
            {
                serviceProviders.Add(row["cardNumber"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }


        [System.Web.Services.WebMethod]
        public static String MapItems(String cardRWId, String cardNumber, String inputAmt, String radioValue)
        {
            
            SqlConnection conn1 = null;
            if (cardRWId.Equals("") || cardNumber.Equals("") || inputAmt.Equals(""))
            {
                return "Please fill all Text fields";
            }

            if (radioValue.Equals("topup"))
            {
                if (!(Convert.ToInt32(inputAmt) % 50 == 0))
                {
                    return "Please enter recharge value with multiples of 50";
                }
                try
                {
                    //---get balance
                    string query = "SELECT Currentbalance FROM [UserPayCard] where cardNumber=" + cardNumber;

                    SqlConnection nConn = new SqlConnection("Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true");
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = query;

                    int id = 0;
                    nConn.Open();
                    cmd.Connection = nConn;
                    id = Convert.ToInt32(cmd.ExecuteScalar());
                    //----end get balance


                    //---enter data to userpaycard table
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                    SqlCommand comm = new SqlCommand();
                    comm.CommandText = "update  [UserpayCard] set CurrentBalance=@balance where CardNumber=@cardnumber";
                    comm.Parameters.AddWithValue("@balance", (id + Int32.Parse(inputAmt)));
                    comm.Parameters.AddWithValue("@cardnumber", cardNumber);


                    conn.Open();
                    comm.Connection = conn;
                    int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                    //end of data entry to userpaycard
                    conn.Close();
                    //transaction table update
                    conn1 = new SqlConnection();
                    conn1.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";

                    SqlCommand comm1 = new SqlCommand();
                    comm1.CommandText = "insert into [Transactions] values(@Trdate,@TransactionType,@CardId,@TrValue)";
                    comm1.Parameters.AddWithValue("@Trdate", DateTime.Now.ToString("yyyy-MM-dd"));
                    comm1.Parameters.AddWithValue("@TransactionType", "Top Up Recharge");
                    comm1.Parameters.AddWithValue("@CardId", cardNumber);
                    comm1.Parameters.AddWithValue("@TrValue", inputAmt);
                    conn1.Open();
                    comm1.Connection = conn1;
                    int ret1 = Convert.ToInt32(comm1.ExecuteNonQuery());

                    if (ret1 == 1)
                    {
                        return "Transaction Successfull";
                    }

                    else
                    {

                        return "Transaction Failed";
                    }
                    //end---
                }
                catch (Exception)
                {

                }
                finally
                {

                    conn1.Close();
                }
                return "Transaction Failed";
            }

                //------charge code
            else if (radioValue.Equals("charge"))
            {
               
                string query = "SELECT Currentbalance FROM [UserPayCard] where cardNumber=" + cardNumber;

                SqlConnection nConn = new SqlConnection("Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true");
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;

                int id = 0;

                try
                {
                    nConn.Open();
                    cmd.Connection = nConn;


                    id = Convert.ToInt32(cmd.ExecuteScalar());
                    if (id < Int32.Parse(inputAmt))
                    {
                        return "Sorry You do not have enough credit balance to make the transaction";
                    }

                    else
                    {
                        string query1 = "SELECT Currentbalance FROM [UserPayCard] where cardNumber=" + cardNumber;

                        SqlConnection nConn1 = new SqlConnection("Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true");
                        SqlCommand cmd1 = new SqlCommand();
                        cmd1.CommandText = query;

                        int id1 = 0;

                        nConn1.Open();
                        cmd.Connection = nConn1;
                        id1 = Convert.ToInt32(cmd.ExecuteScalar());
                        //----end get balance


                        //---enter data to userpaycard table
                        SqlConnection conncharge = new SqlConnection();
                        conncharge.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                        SqlCommand comm = new SqlCommand();
                        comm.CommandText = "update  [UserpayCard] set CurrentBalance=@balance where CardNumber=@cardnumber";
                        comm.Parameters.AddWithValue("@balance", (id1 - Int32.Parse(inputAmt)));
                        comm.Parameters.AddWithValue("@cardnumber", cardNumber);


                        conncharge.Open();
                        comm.Connection = conncharge;
                        int ret2 = Convert.ToInt32(comm.ExecuteNonQuery());
                        //end of data entry to userpaycard
                        conncharge.Close();
                        //transaction table update
                        conncharge = new SqlConnection();
                        conncharge.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";

                        SqlCommand comm1 = new SqlCommand();
                        comm1.CommandText = "insert into [Transactions] values(@Trdate,@TransactionType,@CardId,@TrValue)";
                        comm1.Parameters.AddWithValue("@Trdate", DateTime.Now.ToString("yyyy-MM-dd"));
                        comm1.Parameters.AddWithValue("@TransactionType", "Charge Debit");
                        comm1.Parameters.AddWithValue("@CardId", cardNumber);
                        comm1.Parameters.AddWithValue("@TrValue", inputAmt);
                        conncharge.Open();
                        comm1.Connection = conncharge;
                        int ret3 = Convert.ToInt32(comm1.ExecuteNonQuery());

                        if (ret3 == 1)
                        {
                            return "Transaction Complete";
                        }

                        else
                        {

                            return "Transaction Failed";
                        }
                    }




                }
                catch (Exception)
                {
                    id1 = 1;
                }
                finally
                {
                    nConn.Close();
                }

            }
            return "Sorry No Transaction option selected";
        }

        public static int id1 { get; set; }
    }
}