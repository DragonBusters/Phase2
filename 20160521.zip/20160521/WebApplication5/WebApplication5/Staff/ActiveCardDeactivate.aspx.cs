﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5.Staff
{
    public partial class ActiveCardDeactivate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        [System.Web.Services.WebMethod]
        public static string loadCardNumbers()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select cardNumber from [PayCard] where CardActivationStatus='Active' and discardedcard='No'", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[PayCard]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[PayCard]"].Rows)
            {
                serviceProviders.Add(row["cardNumber"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }


        [System.Web.Services.WebMethod]
        public static String MapItems(String cardNumber, String radioValue)
        {

            

            if (radioValue.Equals("discard"))
            {

                try
                {
                    //---get balance
                   
                    //----end get balance


                    //---enter data to userpaycard table
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                    SqlCommand comm = new SqlCommand();
                    comm.CommandText = "update  [PayCard] set CardActivationStatus=@CardActivationStatus,discardedcard='Yes' where CardNumber=@cardnumber ";

                    comm.Parameters.AddWithValue("@cardnumber", cardNumber);
                    comm.Parameters.AddWithValue("@CardActivationStatus", "Active");


                    conn.Open();
                    comm.Connection = conn;
                    int ret = Convert.ToInt32(comm.ExecuteNonQuery());
                    //end of data entry to userpaycard
                    conn.Close();
                    //transaction table update
                   

                    if (ret == 1)
                    {
                        return "Card successfully deleted";
                    }

                    else
                    {

                        return "Card Deletion failed ";
                    }
                    //end---
                }
                catch (Exception)
                {

                }
                finally
                {

                    
                }
                return "Card Deletion failed ";
            }

                //------charge code
            else if (radioValue.Equals("deactivate"))
            {

                SqlConnection conncharge=null;

                try
                {

                    conncharge = new SqlConnection();
                        conncharge.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
                        SqlCommand comm = new SqlCommand();
                        comm.CommandText = "update  [PayCard] set CardActivationStatus=@CardActivationStatus where CardNumber=@cardnumber";
                      
                        comm.Parameters.AddWithValue("@cardnumber", cardNumber);
                        comm.Parameters.AddWithValue("@CardActivationStatus", "Inactive");


                        conncharge.Open();
                        comm.Connection = conncharge;
                        int ret2 = Convert.ToInt32(comm.ExecuteNonQuery());
                        //end of data entry to userpaycard
                        
                        //transaction table update
                       

                        if (ret2 == 1)
                        {
                            return "Card Successfully deactivated";
                        }

                        else
                        {

                            
                        }
                    }


           
                catch (Exception)
                {

                }
                finally
                {
                    conncharge.Close();
                }
                
            }
            return "No options Selected";
        }
    }
}