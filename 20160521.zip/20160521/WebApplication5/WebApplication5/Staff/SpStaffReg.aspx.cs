﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace WebApplication5.Staff
{
    public partial class SpStaffRegisterv2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
         [System.Web.Services.WebMethod]
        public static string loadServiceNames()
        {
            string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";
            List<String> serviceProviders = new List<string>();


            SqlDataAdapter da = new SqlDataAdapter("select serviceName from [serviceProvider]", constring);
            DataSet ds = new DataSet();
            da.Fill(ds, "[serviceProvider]");

            //List<string> authorNames = new List<string>();
            foreach (DataRow row in ds.Tables["[serviceProvider]"].Rows)
            {
                serviceProviders.Add(row["serviceName"].ToString());

            }
            return JsonConvert.SerializeObject(serviceProviders);
        }

        [System.Web.Services.WebMethod]
        public static String registerSP(String providerName, String staffId, String firstName, String lastName, String Address, String cellNumber, String RegDate, String Age, String EmailId)
        {
            DateTime now = DateTime.Now;
            RegDate = now.ToString("dd/MM/yyyy");
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source = BLRKEC87381L; Initial Catalog = TechEngage;Integrated Security=true";
            SqlCommand comm = new SqlCommand();
            comm.CommandText = "insert into [SPStaff] values(@SPName,@StaffId,@Fname,@LName,@Address,@CellNumber,@RegDate,@Age,@EmailID)";
            comm.Parameters.AddWithValue("@SPName", providerName);
            comm.Parameters.AddWithValue("@StaffId", staffId);
            comm.Parameters.AddWithValue("@Fname", firstName);
            comm.Parameters.AddWithValue("@Lname", lastName);
            comm.Parameters.AddWithValue("@Address", Address);
            comm.Parameters.AddWithValue("@CellNumber", cellNumber);
            comm.Parameters.AddWithValue("@RegDate", RegDate);
            comm.Parameters.AddWithValue("@Age", Age);
            comm.Parameters.AddWithValue("@EmailId", EmailId);
            conn.Open();
            comm.Connection = conn;
            int ret = Convert.ToInt32(comm.ExecuteNonQuery());
            if (ret == 1)
                return "Registration Successfull";

            else
            {
                return "Registration Failed";
            }
        }
        [System.Web.Services.WebMethod]
        public static String createStaffId(String providerName)
        {
            String staffId = "";
            String staffString = "";
            try
            {
                string constring = "Data Source= BLRKEC87381L ; Initial Catalog=TechEngage;Integrated Security=True";


                using (SqlConnection connection = new SqlConnection(constring))
                {
                    string query = "SELECT StaffID FROM [SPStaff] where SPName='" + providerName + "' order  by StaffID desc";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        reader.Read();
                        staffId = reader.GetString(0);
                        if (!(staffId == null || staffId.Equals("")))
                        {
                            int index = staffId.IndexOf("000");
                            int id = Int32.Parse(staffId.Substring(index));
                            id++;
                            staffString = providerName + "000" + id;
                        }
                        else
                        {

                            staffString = providerName + "000" + 1;
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            }
            catch (Exception)
            {
                staffString = providerName + "000" + 1;
            }
            return staffString;
        }
    
    }
}