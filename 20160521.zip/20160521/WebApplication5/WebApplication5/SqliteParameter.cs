﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebApplication5
{
    class SqliteParameter
    {
        private string p1;
        private string p2;
        private int p3;

        public SqliteParameter(string p1, string p2)
        {
            // TODO: Complete member initialization
            this.p1 = p1;
            this.p2 = p2;
        }

        public SqliteParameter(string p1, int p3)
        {
            // TODO: Complete member initialization
            this.p1 = p1;
            this.p3 = p3;
        }
    }
}
